/*var name = prompt('ваше имя');

document.write('hello ' + name);

if(name == "Andrei"){
	document.write('hello Andrei');
	//Здесь работают команды в случае истины
} else if(name == "Pit"){
	document.write('hello Pit');
} else if(name == "Kate"){
	document.write('hello Kate');
} 
else{
	document.write('hello no-name');
	// Команды в случае не верного условия (ложь)
}*/
// alert();
// document.write();
var name = "Ivan";
console.log("Hello");